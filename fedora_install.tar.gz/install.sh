#!/bin/sh
echo "This installer install behafucha version 0.9.5 on Fedora 36, 37"
echo "press 'y' to continue"
read USER_DECISION
if test $USER_DECISION = "y"; then
  rpm -qa | grep ydotool 1>/dev/null 2>/dev/null || sudo dnf install ydotool
  sudo mkdir /usr/share/doc/behafucha 2>/dev/null
  sudo cp -p src/bin/behafucha /usr/bin/
  sudo cp -p src/applications/behafucha.desktop /usr/share/applications/behafucha.desktop
  sudo cp -p src/share/doc/behafucha/*.md /usr/share/doc/behafucha/
  sudo cp -p src/share/pixmaps/behafucha.png /usr/share/pixmaps/
  sudo chmod +s /usr/bin/ydotool
  sudo systemctl start ydotool
  sudo systemctl enable ydotool
  echo
  echo "Successful !!!"
else
   echo
   echo "Quit without installing behafucha"
fi


