#!/bin/sh
echo "This installer will install behafucha on non Debain\Ubuntu  based OS"
echo "press any key to continue (q - to quit)"
read USER_DECISION
if test $USER_DECISION != "q"; then
  sudo mkdir /usr/lib/behafucha 2>/dev/null
  sudo mkdir /usr/share/doc/behafucha 2>/dev/null
  sudo cp -p src/lib/behafucha.py /usr/lib/behafucha/
  sudo cp -p src/lib/ctrl_v /usr/lib/behafucha/
  sudo cp -p src/bin/behafucha /usr/bin/
  sudo cp -p src/applications/behafucha.desktop /usr/share/applications/behafucha.desktop
  sudo cp -p src/share/doc/behafucha/*.md /usr/share/doc/behafucha/
  sudo cp -p src/share/pixmaps/behafucha.png /usr/share/pixmaps/
  echo
  echo "Successful !!!"
else
   echo
   echo "Quit without installing behafucha"
fi


