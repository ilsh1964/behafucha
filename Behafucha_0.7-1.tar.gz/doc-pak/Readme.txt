Behafucha - Ver 0.6  

Authors: Ilan Shavit, ilan.shavit@gmail.com, http://ilsh.info
         Moshe Wagner, moshe.wagner@gmail.com, http://dosilinux.wordpress.com



1. Behafucha: Converts English/Hebrew to Hebrew/English text (like "Hafuch Al Hafuch")

2. Install:
     sudo apt-get install behafucha_0.6-1_all.deb

3. Usage:
   a. Mark the text
   b. Run 'Behafucha' (Application->Accessories->Behafucha)

4. Licence: 
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License version 2
   as published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

